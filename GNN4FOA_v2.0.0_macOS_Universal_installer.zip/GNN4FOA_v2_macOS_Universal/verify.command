#!/bin/bash
set -euo pipefail
for B in "$HOME/Library/Audio/Plug-Ins/Components/GNN4FOA_v2.component/Contents/MacOS/GNN4FOA_v2" "$HOME/Library/Audio/Plug-Ins/VST3/GNN4FOA_v2.vst3/Contents/MacOS/GNN4FOA_v2"; do
  echo "== $B =="
  [ -f "$B" ] || { echo "MISSING"; continue; }
  lipo -info "$B"
  echo "backend symbols:"
  nm -u "$B" 2>/dev/null | grep -E 'vDSP_mmul|cblas_|NEWLAPACK' || true
  strings "$B" | grep -E 'GNN4FOA-V2.0.0-ISPL|GNN4FOA_v2' | head || true
  codesign --verify --deep --strict --verbose=2 "$(dirname "$(dirname "$B")")" 2>&1 || true
  echo
done
