#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p "$HOME/Library/Audio/Plug-Ins/Components" "$HOME/Library/Audio/Plug-Ins/VST3"
rm -rf "$HOME/Library/Audio/Plug-Ins/Components/GNN4FOA_v2.component"
rm -rf "$HOME/Library/Audio/Plug-Ins/VST3/GNN4FOA_v2.vst3"
ditto "Payload/GNN4FOA_v2.component" "$HOME/Library/Audio/Plug-Ins/Components/GNN4FOA_v2.component"
ditto "Payload/GNN4FOA_v2.vst3" "$HOME/Library/Audio/Plug-Ins/VST3/GNN4FOA_v2.vst3"
xattr -dr com.apple.quarantine "$HOME/Library/Audio/Plug-Ins/Components/GNN4FOA_v2.component" 2>/dev/null || true
xattr -dr com.apple.quarantine "$HOME/Library/Audio/Plug-Ins/VST3/GNN4FOA_v2.vst3" 2>/dev/null || true
killall -9 AudioComponentRegistrar 2>/dev/null || true
killall -9 auvaltool 2>/dev/null || true
echo "Installed GNN4FOA_v2. Restart your DAW and rescan plug-ins if needed."
